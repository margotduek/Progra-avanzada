1. compile server "gcc simple_server.c -o server"
2. compile client "gcc simple_client.c -o client"
3. run ./server 8888 (or any free port) on a terminal
4. run ./client localhost 8888 (or the port you chossed and if you are connecting from an other computer put the ip instead of localhost)
5. repeat step 4 as many times as you want to or as many pleyers you have
6. start playing 